/* eslint-env node */
/* eslint-disable-next-line */
const plugin = require('tailwindcss/plugin')

module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  plugins: []
}
