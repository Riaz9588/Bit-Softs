import React from 'react'
import { containerMaxW } from '../utils/config'


export default function NavBar() {
  return (
    <nav className={`py-2 px-6 ${containerMaxW}`}>
      Navabr
    </nav>
  )
}
