import { NhostClient } from '@nhost/nhost-js'

const nhost = new NhostClient({
  subdomain: 'occkhlyrkilpbdqnlvph',
  region: 'ap-south-1'
})

export default nhost